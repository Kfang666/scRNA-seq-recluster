test_that("Clustering refinement works", {
  # 加载测试数据
  data(pbmc)
  
  # 运行主函数
  result <- iterative_clustering(pbmc, 
                                 cell_threshold = 30,
                                 max_iterations = 3)
  
  # 验证结果
  expect_true("seurat_clusters_recluster" %in% colnames(result@meta.data))
  expect_lte(max(table(result$seurat_clusters_recluster)), 30)
})

test_that("Parameter validation works", {
  expect_error(iterative_clustering(pbmc, cell_threshold = -1))
  expect_error(iterative_clustering(pbmc, resolution = 0))
})